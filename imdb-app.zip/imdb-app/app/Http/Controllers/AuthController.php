<?php

namespace App\Http\Controllers;

use App\Mail\ResetPasswordMail;
use App\Models\User;
use Illuminate\Auth\Notifications\ResetPassword;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Session;

class AuthController extends Controller
{
    public function getSignIn() {
        return view('auth.signin');
    }
    public function getSignUp(){
        return view('auth.signup');
    }
    public function getEmail(){
        return view('auth.emailcheck');
    }
    public function getResetPassword($id){
        $userId = User::find($id)->id;
        return view('auth.resetpassword', compact('userId'));
    }
    public function getSettings(){
        return view('auth.settings');
    }

    public function signUp(Request $request) {
        if(Auth::check()) {
            return redirect('/signup')->withErrors('You are already signed in!');
        }

        $request->validate([
            'name' => 'required|min:2|max:255|string',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|confirmed|min:3|max:255|string|confirmed',
        ]);

        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password)
        ]);
        

        return redirect('/signin')->with('status', 'You have signed up!');
    }

    public function signIn(Request $request) {
        if(Auth::check()) {
            return redirect('/signin')->withErrors('You are already signed in!');
        }

        $request->validate([
            'email' => 'required|exists:users,email',
            'password' => 'required'
        ]);

        $credentials = $request->only('email', 'password');
        if(Auth::attempt($credentials)) {
            return redirect()->intended('/')->with('status', 'Sign in');
        }

        return redirect('/')->withErrors('Invalid credentials');
    }
    public function signOut() {
        Session::flush();
        Auth::logout();

        return Redirect('signin');
    }

    public function emailCheck(Request $request){
        $request->validate([
            'email' => 'required|exists:users,email'
        ]);

        $user = User::where('email', $request->email)->get()->first();

        $mailData = $user->only('id');
        Mail::to($request->email)->send(new ResetPasswordMail($mailData));

        return redirect()->intended('emailcheck')->with('status', 'Mail sent');
    }
    
    public function resetPassword(Request $request){
        $request->validate([
            'password' => 'required|confirmed|min:3|max:255|string|confirmed',
            'user_id' => 'required'
        ]);

        $user = User::find($request->user_id);
        $user->password = Hash::make($request->password);
        $user->save();

        return redirect()->intended('signin');

    }

    public function changePassword(Request $request){
        $request->validate([
            'password' => 'required|confirmed'
        ]);

        $user = User::find(Auth::user()->id);
        $newPassword = Hash::make($request->password);
        if(Hash::check($request->password, $user->password)) {
            return redirect('settings')->withErrors('New password must be different from old password!');
        }
        $user->password = Hash::make($request->password);
        $user->save();

        return redirect()->intended('/');

    }

    
}
