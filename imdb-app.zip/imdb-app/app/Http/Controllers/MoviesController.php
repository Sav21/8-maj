<?php

namespace App\Http\Controllers;

use App\Models\Genre;
use App\Models\Movie;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class MoviesController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $movies = Movie::paginate(12);
        $genres = Genre::all();
        return view('movies', compact('movies', 'genres'));
    }

    public function getFiltered(Request $request) {
        $genre = Genre::find($request->genre);
        $movies = $genre->movies()->paginate(12);
        $genres = Genre::all();
        return view('movies', compact('movies', 'genres'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|min:5|max:255|string',
            'year' => 'required|min:2|max:5000|string',
            'duration' => 'required',
            'user_score' => 'required',
            'pegi' => 'required',
            'img_url' => 'required',
            'description' => 'required',
            'published_at' => 'required',

            
        ]);

        $movie = new Movie();

        $movie->title = $request->title;
        $movie->year = $request->year;
        $movie->duration = $request->duration;
        $movie->user_score = $request->user_score;
        $movie->pegi = $request->pegi;
        $movie->img_url = $request->img_url;
        $movie->description = $request->description;
        $movie->published_at = $request->published_at;


        $movie->save();

        // foreach($request->genres as $genreId){
        //     $movie->genres()->attach($genreId);
        // }

        // $mailData = $post->only('title', 'body', 'image_url');
        // Mail::to($user->email)->send(new CreatePostMail($mailData));

        return redirect('createmovie')->with('status', 'Movie successfully posted');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $movie = Movie::with('genres')->find($id);
        return view('singlemovie', compact('movie'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }

    public function createMovie() {
        $genres = Genre::all();
        return view('createmovie', compact('genres'));
    }
}
