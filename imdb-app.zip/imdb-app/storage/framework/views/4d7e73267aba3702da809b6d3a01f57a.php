<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

    Click <a href="http://localhost:8000/resetpassword/<?php echo e($mailData['id']); ?>">here</a> to reset your password
    
</body>
</html><?php /**PATH /Users/vivify/Desktop/treci-cas/imdb-app/resources/views/mails/reset.blade.php ENDPATH**/ ?>