<?php $__env->startSection('content'); ?>

<form action="<?php echo e(url('create')); ?>" method="POST">
  <?php echo csrf_field(); ?>
  <div class="mb-3">
    <label class="form-label">Title</label>
    <input type="text" class="form-control" name="title" required />
  </div>
  <div class="mb-3">
    <label class="form-label">Date</label>
    <textarea type="text" name="year" class="form-control" required></textarea>
  </div>
  <div class="mb-3">
    <label class="form-label">Duration</label>
    <textarea type="text" name="duration" class="form-control" required></textarea>
  </div>
  <div class="mb-3">
    <label class="form-label">Score</label>
    <textarea type="text" name="user_score" class="form-control" required></textarea>
  </div>
  <div class="mb-3">
    <label class="form-label">Pegi</label>
    <textarea type="text" name="pegi" class="form-control" required></textarea>
  </div>
  <div class="mb-3">
    <label class="form-label">Image Url</label>
    <input type="text" class="form-control" name="img_url" required />
  </div>
  <div class="mb-3">
    <label class="form-label">Description</label>
    <textarea type="text" name="description" class="form-control" required></textarea>
  </div>
  <div class="mb-3">
    <label class="form-label">Published at</label>
    <textarea type="text" name="published_at" class="form-control" required></textarea>
  </div>
</div>

  <button type="submit" class="btn btn-primary">Create Post</button>
</form>


<?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.session', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/vivify/Desktop/treci-cas/imdb-app/resources/views/createmovie.blade.php ENDPATH**/ ?>