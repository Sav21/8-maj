<?php $__env->startSection('content'); ?>
    <div class="container text-align ">
        <h1 class="mt-2"><?php echo e($movie->title); ?></h1>
        
        <img class="mt-5" src="<?php echo e($movie->img_url); ?>" alt="PostImage">
        <h6>Genre:</h6>
        <?php $__currentLoopData = $movie->genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <ul>
            <li><?php echo e($genre->name); ?></li>
        </ul>
            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        <p class="mt-5"><?php echo e($movie->description); ?></p>
        
    </div>

    

    <form action="createcomment" method="POST" class="mt-5">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label class="form-label">Enter your comment</label>
            <textarea type="text" class="form-control" name="body" required></textarea>
            <input type="hidden" name="movie_id" value="<?php echo e($movie->id); ?>">
        </div>
        <button type="submit" class="btn btn-primary">Post Comment</button>
    </form>

    <?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.session', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('components.comment', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/vivify/Desktop/treci-cas/imdb-app/resources/views/singlemovie.blade.php ENDPATH**/ ?>