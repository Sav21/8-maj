<?php $__env->startSection('title'); ?>Posts <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<form class="flex" action="<?php echo e(url('filter')); ?>" method="GET">
  <select name="genre" class="form-select">
    <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <option value="<?php echo e($genre->id); ?>"><?php echo e($genre->name); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
  <button type="submit" class="btn btn-primary">Filter</button>
</form>
<div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
  <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo $__env->make('components.movie', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>

<?php echo e($movies); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/vivify/Desktop/treci-cas/imdb-app/resources/views/movies.blade.php ENDPATH**/ ?>