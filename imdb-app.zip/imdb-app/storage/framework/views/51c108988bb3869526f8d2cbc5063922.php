<?php $__env->startSection('content'); ?>

<form action="<?php echo e(url('resetpassword')); ?>" method="POST">
  <?php echo csrf_field(); ?>
  <div class="mb-3">
    <label class="form-label">New Password</label>
    <input type="password" class="form-control" name="password" required />
  </div>
  <div class="mb-3">
    <label class="form-label">Confirm New Password</label>
    <input type="password" class="form-control" name="password_confirmation" required />
    <input type="hidden" class="form-control" name="user_id" value="<?php echo e($userId); ?>" required />
  </div>
  <button type="submit" class="btn btn-primary">Reset Password</button>
</form>


<?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.session', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/vivify/Desktop/treci-cas/imdb-app/resources/views/auth/resetpassword.blade.php ENDPATH**/ ?>