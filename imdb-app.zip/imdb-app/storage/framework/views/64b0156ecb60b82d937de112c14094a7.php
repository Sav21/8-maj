<div class="col">
    <div class="card shadow-sm">
      <img src="<?php echo e($movie->img_url); ?>" alt="img">
      <div class="card-body">
        <h6><?php echo e($movie->title); ?></h6>
        <p class="card-text"><?php echo e($movie->published_at); ?></p>
        <p class="card-text"><?php echo e($movie->year); ?></p>

        <div class="d-flex justify-content-between align-items-center">
          <div class="btn-group">
            <a href="/movies/<?php echo e($movie->id); ?>" class="btn btn-sm btn-outline-secondary">View</a>
            <button type="button" class="btn btn-sm btn-outline-secondary">Edit</button>
          </div>
          <small class="text-body-secondary"><?php echo e($movie->created_at->diffForHumans()); ?></small>
        </div>
      </div>
    </div>
  </div>


  
  


<?php /**PATH /Users/vivify/Desktop/treci-cas/imdb-app/resources/views/components/movie.blade.php ENDPATH**/ ?>