<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\CommentsController;
use App\Http\Controllers\GenresController;
use App\Http\Controllers\MoviesController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/emailcheck', [AuthController::class, 'getEmail']);
Route::post('/emailcheck', [AuthController::class, 'emailCheck']);

Route::get('/resetpassword/{id}', [AuthController::class, 'getResetPassword']);
Route::post('/resetpassword', [AuthController::class, 'resetPassword']);

Route::get('/settings', [AuthController::class, 'getSettings']);
Route::post('/settings', [AuthController::class, 'changePassword']);


Route::get('/createmovie', [MoviesController::class, 'createMovie']);
Route::post('/create', [MoviesController::class, 'store']);



Route::post('/movies/createcomment', [CommentsController::class, 'store']);

Route::get('/signin', [AuthController::class, 'getSignin']);
Route::get('/signup', [AuthController::class, 'getSignup']);
Route::post('/signup', [AuthController::class, 'signUp']);
Route::post('/signin', [AuthController::class, 'signIn']);
Route::get('/signout', [AuthController::class, 'signOut']);

Route::get('/movies', [MoviesController::class, 'index']);
Route::get('/movies/{id}', [MoviesController::class, 'show']);

Route::get('/genres', [GenresController::class, 'index']);
Route::get('/genres/{id}', [GenresController::class, 'show']);
Route::get('/filter', [MoviesController::class, 'getFiltered']);

// Route::get('/', [MoviesController::class, 'index']);



Route::get('/', function () {
    return view('welcome');
});

