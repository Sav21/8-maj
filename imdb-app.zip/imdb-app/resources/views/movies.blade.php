@extends('layouts.default')


@section('title')Posts @endsection

@section('content')

<form class="flex" action="{{url('filter')}}" method="GET">
  <select name="genre" class="form-select">
    @foreach ($genres as $genre)
     <option value="{{$genre->id}}">{{$genre->name}}</option>
    @endforeach
  </select>
  <button type="submit" class="btn btn-primary">Filter</button>
</form>
<div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
  @foreach ($movies as $movie)
    @include('components.movie')
  @endforeach

</div>

{{$movies}}

@endsection