
<nav class="navbar navbar-expand-sm navbar-dark bg-dark" aria-label="Third navbar example">
  <div class="container-fluid">
    <a class="navbar-brand" href="/">IMDB</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsExample03" aria-controls="navbarsExample03" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarsExample03">
      <ul class="navbar-nav me-auto mb-2 mb-sm-0">
        <a class="nav-link active" aria-current="page" href="/movies">Movies</a>
        <a class="nav-link active" aria-current="page" href="/genres">Genres</a>
        <a class="nav-link active" aria-current="page" href="/createmovie">Post movie</a>

        <li class="nav-item dropdown">
          @if(!auth()->check())
            <a href="/signin"><button type="button" class="btn btn-outline-light me-2">Login</button></a>
            <a href="/signup"><button type="button" class="btn btn-warning">Sign up</button></a>
            @else
          <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown" aria-expanded="false">Dropdown</a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="#">Profile</a></li>
              <li><a class="dropdown-item" href="signout">Sign out</a></li>
              <li><a class="dropdown-item" href="settings">Settings</a></li>
            </ul>
          </li>
        </ul>
        @endif
    </div>
  </div>
</nav>
