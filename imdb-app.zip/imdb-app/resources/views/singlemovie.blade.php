@extends('layouts.default')


@section('content')
    <div class="container text-align ">
        <h1 class="mt-2">{{ $movie->title }}</h1>
        {{-- <h3 class="mt-2">{{  }}</h3> --}}
        <img class="mt-5" src="{{ $movie->img_url }}" alt="PostImage">
        <h6>Genre:</h6>
        @foreach ($movie->genres as $genre)
        <ul>
            <li>{{$genre->name}}</li>
        </ul>
            
        @endforeach
        {{-- <a href="">{{$movie->id}}</a> --}}
        <p class="mt-5">{{ $movie->description }}</p>
        
    </div>

    

    <form action="createcomment" method="POST" class="mt-5">
        @csrf
        <div class="mb-3">
            <label class="form-label">Enter your comment</label>
            <textarea type="text" class="form-control" name="body" required></textarea>
            <input type="hidden" name="movie_id" value="{{ $movie->id }}">
        </div>
        <button type="submit" class="btn btn-primary">Post Comment</button>
    </form>

    @include('layouts.errors')
    @include('layouts.session')
    @include('components.comment')
@endsection
