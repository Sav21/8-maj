<div class="col">
    <div class="card shadow-sm">
      <img src="{{ $movie->img_url }}" alt="img">
      <div class="card-body">
        <h6>{{$movie->title}}</h6>
        <p class="card-text">{{ $movie->published_at }}</p>
        <p class="card-text">{{ $movie->year }}</p>

        <div class="d-flex justify-content-between align-items-center">
          <div class="btn-group">
            <a href="/movies/{{ $movie->id }}" class="btn btn-sm btn-outline-secondary">View</a>
            <button type="button" class="btn btn-sm btn-outline-secondary">Edit</button>
          </div>
          <small class="text-body-secondary">{{ $movie->created_at->diffForHumans(); }}</small>
        </div>
      </div>
    </div>
  </div>


  {{-- 2010-02-13 --}}
  {{-- 2009-12-26 --}}


