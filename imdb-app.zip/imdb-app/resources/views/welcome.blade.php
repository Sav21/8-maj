@extends('layouts.default')
{{-- @include('components.movie') --}}