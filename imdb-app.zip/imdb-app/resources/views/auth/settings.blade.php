@extends('layouts.default')



@section('content')

<form action="{{ url('settings') }}" method="POST">
  @csrf
  <div class="mb-3">
    <label class="form-label">Old Password</label>
    <input type="password" class="form-control" name="old_password" required />
  </div>
  <div class="mb-3">
    <label class="form-label">New Password</label>
    <input type="password" class="form-control" name="password" required />
  </div>
  <div class="mb-3">
    <label class="form-label">Confirm New Password</label>
    <input type="password" class="form-control" name="password_confirmation" required />

  </div>
  <button type="submit" class="btn btn-primary">Reset Password</button>
</form>


@include('layouts.errors')
@include('layouts.session')

@endsection