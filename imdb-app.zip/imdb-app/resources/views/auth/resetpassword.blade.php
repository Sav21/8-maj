@extends('layouts.default')



@section('content')

<form action="{{ url('resetpassword') }}" method="POST">
  @csrf
  <div class="mb-3">
    <label class="form-label">New Password</label>
    <input type="password" class="form-control" name="password" required />
  </div>
  <div class="mb-3">
    <label class="form-label">Confirm New Password</label>
    <input type="password" class="form-control" name="password_confirmation" required />
    <input type="hidden" class="form-control" name="user_id" value="{{$userId}}" required />
  </div>
  <button type="submit" class="btn btn-primary">Reset Password</button>
</form>


@include('layouts.errors')
@include('layouts.session')

@endsection