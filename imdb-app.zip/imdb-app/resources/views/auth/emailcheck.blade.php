@extends('layouts.default')



@section('content')

<form action="{{ url('emailcheck') }}" method="POST">
  @csrf
  <div class="mb-3">
    <label class="form-label">Entter Your Email</label>
    <input type="email" class="form-control" name="email" required />
  </div>
  <button type="submit" class="btn btn-primary">Sign in</button>

</form>


@include('layouts.errors')
@include('layouts.session')

@endsection