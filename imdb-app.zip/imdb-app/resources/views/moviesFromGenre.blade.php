@extends('layouts.default')
@section('content')

@foreach ($genre->movies as $movie)
    <li>{{$movie->title}}</li>
@endforeach


@endsection