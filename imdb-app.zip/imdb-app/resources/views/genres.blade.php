@extends('layouts.default')


@section('title')Posts @endsection

@section('content')


<div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
  
  {{-- <select name="genres" class="form-select">
    @foreach ($genres as $genre)
    
    <option value="{{$genre->id}}">{{$genre->name}}</option>
      
    @endforeach
  </select> --}}

  @foreach ($genres as $genre)
    <a href="/genres/{{$genre->id}}"><li>{{$genre->name}}</li></a>
  @endforeach

</div>

{{$genres}}

@endsection